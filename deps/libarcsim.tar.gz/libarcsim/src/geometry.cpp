/*
  Copyright ©2013 The Regents of the University of California
  (Regents). All Rights Reserved. Permission to use, copy, modify, and
  distribute this software and its documentation for educational,
  research, and not-for-profit purposes, without fee and without a
  signed licensing agreement, is hereby granted, provided that the
  above copyright notice, this paragraph and the following two
  paragraphs appear in all copies, modifications, and
  distributions. Contact The Office of Technology Licensing, UC
  Berkeley, 2150 Shattuck Avenue, Suite 510, Berkeley, CA 94720-1620,
  (510) 643-7201, for commercial licensing opportunities.

  IN NO EVENT SHALL REGENTS BE LIABLE TO ANY PARTY FOR DIRECT,
  INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
  LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND ITS
  DOCUMENTATION, EVEN IF REGENTS HAS BEEN ADVISED OF THE POSSIBILITY
  OF SUCH DAMAGE.

  REGENTS SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
  FOR A PARTICULAR PURPOSE. THE SOFTWARE AND ACCOMPANYING
  DOCUMENTATION, IF ANY, PROVIDED HEREUNDER IS PROVIDED "AS
  IS". REGENTS HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT,
  UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
*/

#include "geometry.hpp"
#include <cstdlib>

using namespace std;

namespace arcsim {
    double signed_vf_distance(const Vec3 &x,
                              const Vec3 &y0, const Vec3 &y1, const Vec3 &y2,
                              Vec3 *n, double *w) {
        Vec3 _n;
        if (!n) n = &_n;
        double _w[4];
        if (!w) w = _w;
        *n = cross(normalize(y1 - y0), normalize(y2 - y0));
        if (norm2(*n) < 1e-6)
            return infinity;
        *n = normalize(*n);
        double h = dot(x - y0, *n);
        double b0 = stp(y1 - x, y2 - x, *n),
                b1 = stp(y2 - x, y0 - x, *n),
                b2 = stp(y0 - x, y1 - x, *n);
        w[0] = 1;
        w[1] = -b0 / (b0 + b1 + b2);
        w[2] = -b1 / (b0 + b1 + b2);
        w[3] = -b2 / (b0 + b1 + b2);
        return h;
    }

    double signed_ee_distance(const Vec3 &x0, const Vec3 &x1,
                              const Vec3 &y0, const Vec3 &y1,
                              Vec3 *n, double *w) {

        Vec3 _n;
        if (!n) n = &_n;
        double _w[4];
        if (!w) w = _w;
        *n = cross(normalize(x1 - x0), normalize(y1 - y0));
        if (norm2(*n) < 1e-6)
            return infinity;
        *n = normalize(*n);
        double h = dot(x0 - y0, *n);
        double a0 = stp(y1 - x1, y0 - x1, *n), a1 = stp(y0 - x0, y1 - x0, *n),
                b0 = stp(x0 - y1, x1 - y1, *n), b1 = stp(x1 - y0, x0 - y0, *n);
        w[0] = a0 / (a0 + a1);
        w[1] = a1 / (a0 + a1);
        w[2] = -b0 / (b0 + b1);
        w[3] = -b1 / (b0 + b1);
        return h;
    }

    bool set_unsigned_ve_distance(const Vec3 &x, const Vec3 &y0, const Vec3 &y1,
                                  double *_d, Vec3 *_n,
                                  double *_wx, double *_wy0, double *_wy1) {
        double t = clamp(dot(x - y0, y1 - y0) / dot(y1 - y0, y1 - y0), 0., 1.);
        Vec3 y = y0 + t * (y1 - y0);
        double d = norm(x - y);
        if (d < *_d) {
            *_d = d;
            *_n = normalize(x - y);
            *_wx = 1;
            *_wy0 = 1 - t;
            *_wy1 = t;
            return true;
        }
        return false;
    }

    bool set_unsigned_vf_distance(const Vec3 &x,
                                  const Vec3 &y0, const Vec3 &y1, const Vec3 &y2,
                                  double *_d, Vec3 *_n,
                                  double *_wx,
                                  double *_wy0, double *_wy1, double *_wy2) {
        Vec3 n = normalize(cross(normalize(y1 - y0), normalize(y2 - y0)));
        double d = abs(dot(x - y0, n));
        double b0 = stp(y1 - x, y2 - x, n),
                b1 = stp(y2 - x, y0 - x, n),
                b2 = stp(y0 - x, y1 - x, n);
        if (d < *_d && b0 >= 0 && b1 >= 0 && b2 >= 0) {
            *_d = d;
            *_n = n;
            *_wx = 1;
            *_wy0 = -b0 / (b0 + b1 + b2);
            *_wy1 = -b1 / (b0 + b1 + b2);
            *_wy2 = -b2 / (b0 + b1 + b2);
            return true;
        }
        bool success = false;
        if (b0 < 0
            && set_unsigned_ve_distance(x, y1, y2, _d, _n, _wx, _wy1, _wy2)) {
            success = true;
            *_wy0 = 0;
        }
        if (b1 < 0
            && set_unsigned_ve_distance(x, y2, y0, _d, _n, _wx, _wy2, _wy0)) {
            success = true;
            *_wy1 = 0;
        }
        if (b2 < 0
            && set_unsigned_ve_distance(x, y0, y1, _d, _n, _wx, _wy0, _wy1)) {
            success = true;
            *_wy2 = 0;
        }
        return success;
    }

    bool set_unsigned_ee_distance(const Vec3 &x0, const Vec3 &x1,
                                  const Vec3 &y0, const Vec3 &y1,
                                  double *_d, Vec3 *_n,
                                  double *_wx0, double *_wx1,
                                  double *_wy0, double *_wy1) {
        Vec3 n = normalize(cross(normalize(x1 - x0), normalize(y1 - y0)));
        double d = abs(dot(x0 - y0, n));
        double a0 = stp(y1 - x1, y0 - x1, n), a1 = stp(y0 - x0, y1 - x0, n),
                b0 = stp(x0 - y1, x1 - y1, n), b1 = stp(x1 - y0, x0 - y0, n);
        if (d < *_d && a0 >= 0 && a1 >= 0 && b0 >= 0 && b1 >= 0) {
            *_d = d;
            *_n = n;
            *_wx0 = a0 / (a0 + a1);
            *_wx1 = a1 / (a0 + a1);
            *_wy0 = -b0 / (b0 + b1);
            *_wy1 = -b1 / (b0 + b1);
            return true;
        }
        bool success = false;
        if (a0 < 0
            && set_unsigned_ve_distance(x1, y0, y1, _d, _n, _wx1, _wy0, _wy1)) {
            success = true;
            *_wx0 = 0;
        }
        if (a1 < 0
            && set_unsigned_ve_distance(x0, y0, y1, _d, _n, _wx0, _wy0, _wy1)) {
            success = true;
            *_wx1 = 0;
        }
        if (b0 < 0
            && set_unsigned_ve_distance(y1, x0, x1, _d, _n, _wy1, _wx0, _wx1)) {
            success = true;
            *_wy0 = 0;
            *_n = -*_n;
        }
        if (b1 < 0
            && set_unsigned_ve_distance(y0, x0, x1, _d, _n, _wy0, _wx0, _wx1)) {
            success = true;
            *_wy1 = 0;
            *_n = -*_n;
        }
        return success;
    }

    double unsigned_vf_distance(const Vec3 &x,
                                const Vec3 &y0, const Vec3 &y1, const Vec3 &y2,
                                Vec3 *n, double w[4]) {
        Vec3 _n;
        if (!n) n = &_n;
        double _w[4];
        if (!w) w = _w;
        double d = infinity;
        set_unsigned_vf_distance(x, y0, y1, y2, &d, n, &w[0], &w[1], &w[2], &w[3]);
        return d;
    }

    double unsigned_ee_distance(const Vec3 &x0, const Vec3 &x1,
                                const Vec3 &y0, const Vec3 &y1,
                                Vec3 *n, double w[4]) {
        Vec3 _n;
        if (!n) n = &_n;
        double _w[4];
        if (!w) w = _w;
        double d = infinity;
        set_unsigned_ee_distance(x0, x1, y0, y1, &d, n, &w[0], &w[1], &w[2], &w[3]);
        return d;
    }

    Vec3 get_barycentric_coords(const Vec2 &point, const Face *f) {

        // Compute vectors
        Vec2 v0 = f->v[0]->u - f->v[2]->u;
        Vec2 v1 = f->v[1]->u - f->v[2]->u;
        Vec2 v2 = point - f->v[2]->u;

        // Compute dot products
        double dot00 = dot(v0, v0);
        double dot01 = dot(v0, v1);
        double dot02 = dot(v0, v2);
        double dot11 = dot(v1, v1);
        double dot12 = dot(v1, v2);

        // Compute barycentric coordinates
        double invDenom = 1.f / (dot00 * dot11 - dot01 * dot01);
        double u = (dot11 * dot02 - dot01 * dot12) * invDenom;
        double v = (dot00 * dot12 - dot01 * dot02) * invDenom;

        return Vec3(u, v, 1 - u - v);
    }

// Is the point within the face?
// Adapted from http://www.blackpawn.com/texts/pointinpoly/default.html
    bool is_inside(const Vec2 &point, const Face *f) {
        Vec3 bary = get_barycentric_coords(point, f);
        //printf("UV: %f, %f\n", u, v);
        // Check if point is in triangle
        // 10*epsilon: want to be robust for borders
        return ((bary[0] >= -10 * EPSILON) && (bary[1] >= -10 * EPSILON) && (bary[2] >= -100 * EPSILON));
    }

// Gets the face that surrounds point u in material space
    Face *get_enclosing_face(const Mesh &mesh, const Vec2 &u,
                             Face *starting_face_hint) {

        // Check pointers
        // check_that_pointers_are_sane(mesh);

        for (int f = 0; f < mesh.faces.size(); f++) {

            if (is_inside(u, mesh.faces[f])) {
                return mesh.faces[f];
            }
        }
        return NULL;
    }

    double material_ve_projection(const Vec2 &x, const Vec2 &y0, const Vec2 &y1, Vec2 &proj) {
        Vec2 y0_x = x - y0;
        Vec2 y0_y1 = y1 - y0;
        double proj_len = dot(y0_x, y0_y1) / norm(y0_y1);
        Vec2 proj_temp = y0 + proj_len * normalize(y0_y1);
        proj[0] = proj_temp[0];
        proj[1] = proj_temp[1];
        if (proj_len >= 0 && proj_len <= norm(y0_y1)) {
            return norm(x - proj);
        }
        return -1;
    }

    template<>
    const Vec3 &pos<PS>(const Node *node) { return node->y; }

    template<>
    const Vec3 &pos<WS>(const Node *node) { return node->x; }

    template<>
    Vec3 &pos<PS>(Node *node) { return node->y; }

    template<>
    Vec3 &pos<WS>(Node *node) { return node->x; }

    template<Space s>
    Vec3 nor(const Face *face) {
        const Vec3 &x0 = pos<s>(face->v[0]->node),
                &x1 = pos<s>(face->v[1]->node),
                &x2 = pos<s>(face->v[2]->node);
        return normalize(cross(x1 - x0, x2 - x0));
    }

    template Vec3 nor<PS>(const Face *face);

    template Vec3 nor<WS>(const Face *face);

    double unwrap_angle(double theta, double theta_ref) {
        if (theta - theta_ref > M_PI)
            theta -= 2 * M_PI;
        if (theta - theta_ref < -M_PI)
            theta += 2 * M_PI;
        return theta;
    }

    template<Space s>
    double dihedral_angle(const Edge *edge) {
        // if (!hinge.edge[0] || !hinge.edge[1]) return 0;
        // const Edge *edge0 = hinge.edge[0], *edge1 = hinge.edge[1];
        // int s0 = hinge.s[0], s1 = hinge.s[1];
        // std::cout<<"Safety check\n";
        // std::cout<<"1\n";
        if (!edge->adjf[0] || !edge->adjf[1]){
            std::cout<<"No dihedral one face is missing\n";
            return 0;
        }
        // std::cout<<"2\n";
        Vec3 e = normalize(edge->n[0]->x - edge->n[1]->x);
        // std::cout<<"3\n";
        if (norm2(e) == 0){ 
        std::cout<<"No dihedral edgelength 0 \n";
        return 0;
        }
        // std::cout<<"4\n";
        Vec3 n0 = nor<s>(edge->adjf[0]), n1 = nor<s>(edge->adjf[1]);
        // std::cout<<"5\n";
        if (norm2(n0) == 0 || norm2(n1) == 0) {
            std::cout<<"No dihedral normal =0\n";
            return 0;

        }
        // std::cout<<"6\n";
        double cosine = dot(n0, n1), sine = dot(e, cross(n0, n1));
        // std::cout<<"7\n"; 
        double theta = atan2(sine, cosine);
        // std::cout<<"8\n";
        return unwrap_angle(theta, 0.0);
    }
    

    template double dihedral_angle<PS>(const Edge *edge);

    template double dihedral_angle<WS>(const Edge *edge);


    template<Space s>
    double dihedral_angle(const Edge *edge, Vec3 n0, Vec3 n1) {
        // if (!hinge.edge[0] || !hinge.edge[1]) return 0;
        // const Edge *edge0 = hinge.edge[0], *edge1 = hinge.edge[1];
        // int s0 = hinge.s[0], s1 = hinge.s[1];
        // std::cout<<"Safett check\n";
        // std::cout<<"1\n";
        // if (!edge->adjf[0] || !edge->adjf[1])
        //     return 0;
        // std::cout<<"2\n";
        Vec3 e = normalize(pos<s>(edge->n[0]) - pos<s>(edge->n[1]));
        // std::cout<<"3\n";
        if (norm2(e) == 0) return 0;
        // std::cout<<"4\n";
        // Vec3 n0 = nor<s>(edge->adjf[0]), n1 = nor<s>(edge->adjf[1]);
        // std::cout<<"5\n";
        if (norm2(n0) == 0 || norm2(n1) == 0) return 0;
        // std::cout<<"6\n";
        double cosine = dot(n0, n1), sine = dot(e, cross(n0, n1));
        // std::cout<<"7\n";
        double theta = atan2(sine, cosine);
        // std::cout<<"8\n";
        return unwrap_angle(theta, 0.0);
    }
    

    template double dihedral_angle<PS>(const Edge *edge, Vec3 n0, Vec3 n1);

    template double dihedral_angle<WS>(const Edge *edge, Vec3 n0, Vec3 n1);


    template<Space s>
    Mat2x2 curvature(const Face *face) {
        Mat2x2 S;
        for (int e = 0; e < 3; e++) {
            const Edge *edge = face->adje[e];
            Vec2 e_mat = face->v[PREV(e)]->u - face->v[NEXT(e)]->u,
                    t_mat = perp(normalize(e_mat));
            double theta = dihedral_angle<s>(face->adje[e]);
            S -= 1 / 2. * theta * norm(e_mat) * outer(t_mat, t_mat);
        }
        S /= face->a;
        return S;
    }

    template<Space s>
    Mat2x2 curvature_2(const Face *face) {
        Mat2x2 S;
        // I need to get the u's and  v's
        Vec3 edgesizes;
        // double b = norm( face->v[2]->node->x -face->v[1]->node->x);
        // double c = norm( face->v[0]->node->x - face->v[2]->node->x);
        // double a = norm( face->v[1]->node->x - face->v[0]->node->x);

        Mat3x3 Rotation;
        Vec3 Normal = face->n;

        
       
        Vec3 Axis(0.0,1.0,0.0);
        int flag = 1;
      
        
        Vec3 uvw = cross(Normal,Axis);

        double rcos = dot(Normal,Axis);
        double rsin = norm(uvw);

        if(rsin>1e-7){
            uvw/=rsin;
        }
        else{
            // uvw = Vec3(0.0,0.0,0.0);
            // std::cout<<"Too small\n";
        }
        // std::cout<<"The vector uvw is " << uvw<<" \n";

        Mat3x3 v_x(Vec3(0,uvw[2],-1*uvw[1]), Vec3(-1*uvw[2],0,uvw[0]), Vec3(uvw[1],-1*uvw[0],0));

        // Rotation = rcos*Mat3x3(Vec3(1.0,0.0,0.0),Vec3(0.0,1.0,0.0),Vec3(0.0,0.0,1.0)) + rsin*Mat3x3( Vec3(0,uvw[2],-1*uvw[1]), Vec3(-1*uvw[2],0,uvw[0]), Vec3(uvw[1],-1*uvw[0],0))+(1-rcos)*outer(uvw,uvw)  ;
        
        Rotation = rcos*Mat3x3(Vec3(1.0,0.0,0.0),Vec3(0.0,1.0,0.0),Vec3(0.0,0.0,1.0)) + rsin*v_x +outer(uvw,uvw)*(1-rcos);

        // std::cout<<"Rotation is" << Rotation << " \n";
        // std::cout<<"The normal beforehand was" << Normal << " \n";
        // std::cout<<"Lets see if it works " << Rotation*Normal <<" \n";
        // std::cout<<"Try with x axis" << Rotation * Vec3(1.0,0.0,0.0)<< " \n";
        // std::cout<<"Try with z axis" << Rotation * Vec3(0.0,0.0,1.0)<< " \n";
        // std::cout<<"Can we do the check to see if its unitary? " << transpose(Rotation)*Rotation  << " \n";

        Vec3 spare_vec;
        vector<Vec2> Positions(0);
        for(size_t v = 0; v < 3; v++){
            spare_vec = face->v[v]->node->x;
            spare_vec = Rotation*spare_vec;
            // std::cout<<"The spare vec is" << spare_vec <<" \n";
            // 
            // if(flag == 0) Positions.push_back(Vec2(spare_vec[1],spare_vec[2]));
            if(flag == 1) Positions.push_back(Vec2(spare_vec[0],spare_vec[2]));
            // if(flag == 2) Positions.push_back(Vec2(spare_vec[0],spare_vec[1]));
        }
        // std::cout<<"The positions were " << face->v[0]->node->x  << " " << face->v[1]->node->x << " " << face->v[2]->node->x <<" \n";
        
        // std::cout<<"The positions are  " << Rotation*face->v[0]->node->x  << " " << Rotation*face->v[1]->node->x << " " << Rotation*face->v[2]->node->x <<" \n";
        
    
        for (int e = 0; e < 3; e++) {
            const Edge *edge = face->adje[e];
            // Vec2 e_mat = Vert_positions[e];
            // I cand o a stilly check
            double edge_l = norm(face->v[PREV(e)]->node->x-face->v[NEXT(e)]->node->x);
            double second_edge_l = norm( Positions[PREV(e)]-Positions[NEXT(e)]);
            if(fabs(edge_l-second_edge_l)>1e-4){
                std::cout<<"The edge length absolute difference is" << fabs(edge_l-second_edge_l)<< "the relative difference is"<< fabs(edge_l-second_edge_l)/edge_l <<" \n";
                std::cout<<"Edge orig is" << edge_l << " and the other is " << second_edge_l << " \n";
            }
            // std::cout<<"Edge " << e <<" This two number should be the same " << edge_l << " and "<< second_edge_l <<" are they?\n";
            Vec2 e_mat = Positions[PREV(e)]-Positions[NEXT(e)];
            // Vec2 e_mat = face->v[PREV(e)]->u - face->v[NEXT(e)]->u,
            Vec2 t_mat = perp(normalize(e_mat));
            double theta = dihedral_angle<s>(face->adje[e]);
            S -= 1 / 2. * theta * norm(e_mat) * outer(t_mat, t_mat);
            // if(isnan(theta)){

            //     std::cout<<"Theta is nan"<< theta <<" \n";
            // }
        }
        // std::cout<<" \n";



        // face->a=area;

        // if(face->a<=0 || isnan(face->a)){
        //     std::cout<<"THe area is "<< face->a <<" \n";
        
        // }
        S /= face->a;
        
        // Ok here i do my thing i guess 
        // Eig<2> eig = eigen_decomposition(S);
        // double maxval=std::max(eig.l[0],eig.l[1]);
        // eig.l[0]=maxval;
        // eig.l[1]=eig.l[0];

        // return diag(eig.l);
        
        // S /= area;
        return S;
    }

    template Mat2x2 curvature<PS>(const Face *face);
    template Mat2x2 curvature<WS>(const Face *face);

    template Mat2x2 curvature_2<PS>(const Face *face);
    template Mat2x2 curvature_2<WS>(const Face *face);

    Face *getCommonFace(const Vert *v1, const Vert *v2, const Vert *v3) {

        bool v1null = v1 == NULL || v1 == 0;
        bool v2null = v2 == NULL || v2 == 0;
        bool v3null = v3 == NULL || v3 == 0;

        for (int i = 0; i < v1->adjf.size(); i++) {
            for (int j = 0; j < v2->adjf.size(); j++) {
                for (int k = 0; k < v3->adjf.size(); k++) {
                    if (v1->adjf[i] == v2->adjf[j] && v1->adjf[i] == v3->adjf[k]) {
                        return v1->adjf[i];
                    }
                }
            }
        }

        return NULL;

    }


    Edge *getCommonEdge(const Node *nodeA, const Node *nodeB) {

        for (int i = 0; i < nodeA->adje.size(); i++) {
            for (int j = 0; j < nodeB->adje.size(); j++) {
                if (nodeA->adje[i] == nodeB->adje[j]) {
                    return nodeA->adje[i];
                }
            }
        }

        return NULL;

    }

    Edge *getCommonEdge(const Face *face0, const Face *face1) {

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (face0->adje[i] == face1->adje[j]) {
                    return face0->adje[i];
                }
            }
        }
        return NULL;
    }

    double getSharpAngle(Edge *edge) {
        // currently only consider one piece of cloth
        double angle;
        Face *f1 = edge->adjf[0];
        Face *f2 = edge->adjf[1];
        if (!f1 || !f2) { // boundary
            return 0;
        }
        double dotProd = dot(f1->n, f2->n);
        angle = acos(clamp(dotProd, 0., 1.)) * 180 / M_PI;
        return angle;
    }

    double getSharpAngle(Node *node) {
        // currently only consider one piece of cloth
        double angle = 0;
        Vec3 &n1 = node->n;
        for (int i = 0; i < node->verts[0]->adjf.size(); i++) {
            Vec3 &n2 = node->verts[0]->adjf[i]->n;
            double dotProd = dot(n1, n2);
            double a = acos(clamp(dotProd, 0., 1.)) * 180 / M_PI;
            angle += a;
        }
        return angle / node->verts[0]->adjf.size();
    }

}